#Page 19
dataset<-c(18,18,19,19,19,18,22,20,18,18,17,19,18,24,18,20,18,21,20,17,19) 
library("plyr")
y<-count(dataset)
print(y)
