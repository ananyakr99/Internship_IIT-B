#Page 668

df1<-2
df2<-20
alpha<-0.05
print(qf(1-alpha,df1,df2,lower.tail = FALSE))