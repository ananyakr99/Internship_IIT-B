#Page 666
df1<-5
df2<-4
alpha<-0.10
print(qf(alpha,df1,df2,lower.tail = FALSE))