#Page 331
alpha<-1-0.90
print(qnorm(alpha/2,lower.tail=FALSE))