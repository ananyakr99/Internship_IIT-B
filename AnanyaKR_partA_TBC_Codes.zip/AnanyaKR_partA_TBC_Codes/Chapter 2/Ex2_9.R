#Page 48
v<-c(rep(0,3),rep(1,6),rep(2,6),rep(3,3),rep(4,1))
library("modeest")
print(mfv(v))