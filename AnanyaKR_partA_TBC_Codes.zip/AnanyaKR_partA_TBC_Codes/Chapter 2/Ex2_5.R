#Page 44
dataset<-c(2,-1,0,2)
median<-median(dataset)
print(median)
