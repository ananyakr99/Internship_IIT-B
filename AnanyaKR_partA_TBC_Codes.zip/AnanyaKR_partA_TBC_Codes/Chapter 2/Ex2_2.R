#Page 39
dataset<-c(2,-1,0,2)
mean<-sum(dataset)/length(dataset)
print(mean)