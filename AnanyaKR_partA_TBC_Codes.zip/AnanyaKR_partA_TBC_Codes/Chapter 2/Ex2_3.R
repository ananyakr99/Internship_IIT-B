#Page 40
GPA<-c(1.90,3.00,2.53,3.71,2.12,1.76,2.71,1.39,4.00,3.33)
mean<-mean(GPA)
print(mean)