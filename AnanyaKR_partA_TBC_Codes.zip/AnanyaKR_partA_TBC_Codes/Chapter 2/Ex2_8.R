#Page 48
v<-c(-1,0,2,0)
library("modeest")
print(mfv(v))