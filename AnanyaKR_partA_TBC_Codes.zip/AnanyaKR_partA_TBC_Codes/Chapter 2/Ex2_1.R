#Page 39
data<-c(1,3,4)
a<-sum(data)
print(a)
b<-sum(data^2)  
print(b)
c<-sum((data-1)^2)  
print(c)