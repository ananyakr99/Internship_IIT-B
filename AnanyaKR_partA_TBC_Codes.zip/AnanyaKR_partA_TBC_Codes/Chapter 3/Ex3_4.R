#Page 114
sample_space<-c('b','g')
print(expand.grid(sample_space,sample_space,sample_space))