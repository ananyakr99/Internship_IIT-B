#Page 162
P_a<-92/100
reqd_probability<-print(P_a+P_a-(P_a*P_a))
