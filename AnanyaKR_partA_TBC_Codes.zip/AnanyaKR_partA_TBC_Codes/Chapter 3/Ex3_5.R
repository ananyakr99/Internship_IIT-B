#Page 116
sample_space<-c('H','T')
event_a<-c('H')
event_b<-c('T')
probablility_of_a<-(length(event_a)/length(sample_space))
probablility_of_b<-(length(event_b)/length(sample_space))
print(probablility_of_a)
print(probablility_of_b)