#Page 164
P_d<-90/100
P_not_d<-(1-P_d)
three_dogs_not_d<-print(P_not_d*P_not_d*P_not_d)
three_dogs_d<-print(1-three_dogs_not_d)