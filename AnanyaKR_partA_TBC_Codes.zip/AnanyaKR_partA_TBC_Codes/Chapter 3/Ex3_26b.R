#Page 163
P_b<-89/100
reqd_probability<-print((1-P_b)*(1-P_b))