#Page 113
library("sets")
Sample_space_a<-print(as.set(c('hh','tt','d')))
Sample_space_b<-print(as.set(c('hh','tt','ht','th')))