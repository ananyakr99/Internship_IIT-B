#Page 134
probability_of_1<-1/12
probability_of_6<-3/12
Sum_of_other_probabilities<-1-(probability_of_1+probability_of_6)
probability_of_2<-Sum_of_other_probabilities/4
probability_of_3<-Sum_of_other_probabilities/4
probability_of_4<-Sum_of_other_probabilities/4
probability_of_5<-Sum_of_other_probabilities/4
probability_of_both_events_occuring<-print(probability_of_4+probability_of_6)