#Page 113
library("sets")
Sample_space_b<-print(as.set(c('hh','tt','ht','th')))