#page 140
Prob_of_maths<-63/100
Prob_of_eng<-34/100
Prob_of_eng_and_math<-27/100
Prob_of_eng_or_math<-print((Prob_of_maths+Prob_of_eng)-Prob_of_eng_and_math)