#Page 138
Sample_space<-c('bb','bg','gb','gg')
Sample_B<-c('bb','bg','gb')
Sample_D<-c('bg','gb')
Sample_M<-c('bb','gg')
B_union_D<-print(union(Sample_B,Sample_D))
B_union_M<-print(union(Sample_B,Sample_M))