#Page 112
Sample_space<-c('Heads','Tails')
library("sets")
print(as.set(Sample_space))
