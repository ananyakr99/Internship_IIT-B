#Page 120
probability_of_white_male<-25/100
probability_of_white_female<-26/100
probability_of_black_male<-12/100
probability_of_black_female<-15/100
probability_of_hispanic_male<-6/10
probability_of_hispanic_female<-5/100
probability_of_asian_male<-3/100
probability_of_asian_female<-3/100
probability_of_others_male<-1/100
probability_of_others_female<-4/100

probability_of_black<-print(probability_of_black_male+probability_of_black_female)