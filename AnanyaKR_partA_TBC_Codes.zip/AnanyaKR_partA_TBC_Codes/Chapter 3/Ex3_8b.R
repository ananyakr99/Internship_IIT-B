#Page 119
probability_of_white<-51/100
probability_of_black<-27/100
probability_of_hispanic<-11/10
probability_of_asian<-6/100
probability_of_others<-5/100
print(1-probability_of_white)