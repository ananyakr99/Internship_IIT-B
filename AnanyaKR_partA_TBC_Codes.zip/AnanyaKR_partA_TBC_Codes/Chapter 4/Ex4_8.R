#Page 213
n<-5
p<-0.17
q<-1-p
mean<-print(n*p)
std_dev<-print(sqrt(n*p*q))