#Page 291
mean<-13525
sd<-4180
n<-100
print(mean)
print(sd/sqrt(n))