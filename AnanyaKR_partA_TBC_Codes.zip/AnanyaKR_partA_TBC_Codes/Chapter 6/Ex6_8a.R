#Page 316
x<-102
n<-121
sample_proportion<-x/n
print(sample_proportion)