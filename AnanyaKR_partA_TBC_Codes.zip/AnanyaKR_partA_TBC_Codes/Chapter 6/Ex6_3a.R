#Page 298
n<-50
mean<-112
sd<-40
print(mean)
print(sd/sqrt(n))