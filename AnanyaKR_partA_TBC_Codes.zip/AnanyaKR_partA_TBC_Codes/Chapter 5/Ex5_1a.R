#Page 231
x<-1-0.75
y<-1
print(x*y)