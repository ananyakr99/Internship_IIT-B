#Page 243

x=seq(-4,4,length=200)
y=dnorm(x,mean=0,sd=1)
print(pnorm(-0.25,mean=0,sd=1))

