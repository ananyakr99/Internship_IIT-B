#Page 237
x<-seq(40,100,by=0.1)
y<-dnorm(x,mean=69.75,sd=2.59)
plot(x,y,main="Normal Distribution")
