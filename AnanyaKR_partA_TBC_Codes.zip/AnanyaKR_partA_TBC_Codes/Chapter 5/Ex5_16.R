#Page 277
z<-qnorm(1-0.65,lower.tail = TRUE)
mean<-175
sd<-12
x<-mean+(z)*(sd)
print(x)