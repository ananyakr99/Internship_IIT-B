#Page 231
x<-0.7-0.4
y<-1
print(x*y)