#Page 274
print(qnorm(0.01,lower.tail = FALSE))
print(qnorm(1-0.01,lower.tail=FALSE))