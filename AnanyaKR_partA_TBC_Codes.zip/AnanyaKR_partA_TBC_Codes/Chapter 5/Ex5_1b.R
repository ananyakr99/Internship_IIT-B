#Page 231
x<-0.2-0
y<-1
print(x*y)