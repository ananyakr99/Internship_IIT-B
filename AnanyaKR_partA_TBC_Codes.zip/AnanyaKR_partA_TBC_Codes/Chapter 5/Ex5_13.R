#Page 272
print(qnorm(0.025,lower.tail = FALSE))