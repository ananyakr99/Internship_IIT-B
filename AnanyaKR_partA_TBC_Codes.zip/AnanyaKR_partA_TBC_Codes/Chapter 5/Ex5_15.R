#Page 276
z<-qnorm(0.9332,lower.tail = TRUE)
mean<-10
sd<-2.5
x<-mean+(z)*(sd)
print(x)