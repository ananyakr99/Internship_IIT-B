#Page 233
f<-1/30
y<-10
print(f*y)