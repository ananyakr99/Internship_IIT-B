#Page 271
print(qnorm(0.0125,lower.tail = TRUE))