#Page 278
z<-qnorm(1-0.05,lower.tail = TRUE)
mean<-510
sd<-60
x<-mean+(z)*(sd)
print(x)